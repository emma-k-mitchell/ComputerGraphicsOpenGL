#include <iostream>
#include <cstdlib>
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library
#define STB_IMAGE_IMPLEMENTATION
#include <math.h>

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <vector>
#include "camera.h"         // Camera class
#include "stb_image.h"      // Image loading Utility functions

#define PI 3.14159265358979323846
const float toRadians = PI / 180.0f;

using namespace std;

// Shader Program Macro
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

namespace
{
    const char* const WINDOW_TITLE = "Module Seven Assignment: Final Project"; // Window title

    const int WINDOW_WIDTH = 800;   // Window width
    const int WINDOW_HEIGHT = 600;  // Window height

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        // VAO's
        GLuint pyramidvao;          // Handle for the vertex array object CYLINDER
        GLuint planevao;            // Plane
        GLuint boxvao;              // Cardboard Box
        GLuint lampvao;             // Light source
        GLuint catvao;              // Cat desk light
        GLuint eggvao;              // Easter egg
        // VBO's
        GLuint vbos[2];             // Handles for the vertex buffer objects CYLINDER
        GLuint planevbos[2];        // Plane
        GLuint boxvbos[2];          // Cardboard Box
        GLuint lampvbos[2];         // Light source
        GLuint catvbos[2];          // Cat desk light
        GLuint eggvbos[2];          // Easter egg
        // nIndicies
        GLuint nIndices;            // Number of indices of the mesh CYLINDER
        GLuint nPlaneIndicies;      // Plane
        GLuint nBoxIndicies;        // Cardboard Box
        GLuint nLampIndicies;       // Light source
        GLuint nCatIndicies;        // Cat desk light
        GLuint nEggIndicies;        // Easter egg
    };

    GLFWwindow* gWindow = nullptr;  // Main GLFW window
    GLMesh gMesh;                   // Triangle mesh data
    GLuint gTextureId;              // Texture id CYLINDER
    GLuint gPlaneTextureId;         // Plane
    GLuint gBoxTextureId;           // Cardboard box
    GLuint gCatTextureId;           // Cat desk light
    GLuint gProgramId;              // Shader program
    GLuint gLightShaderId;          // Light Shader program

    // Camera
    Camera gCamera(glm::vec3(0.0f, 3.0f, 4.0f));  // Camera position is a vector in world space
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    // timing
    float gDeltaTime = 0.0f;  // Time between current frame and last frame
    float gLastFrame = 0.0f;  // Time of last frame

    glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);  // moved here to take it out of the render loop

    // Light source position
    glm::vec3 lightPosition(0.0f, 5.0f, 2.0f);  //  x, y, and z coords for the light source position
}

// Functions
bool UInitialize(int, char* [], GLFWwindow** window);                             // Initialize the program
void UResizeWindow(GLFWwindow* window, int width, int height);                    // Redraw graphics when the widow is resized
void UProcessInput(GLFWwindow* window);                                           // Process input
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);        // Called whenever mouse moves
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);    // Called whenever mouse wheel is scrolled
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);  // Called whenever mouse buttons are pressed
void UCreateMesh(GLMesh& mesh);                                                   // Create mesh & destroy mesh (below)
void UDestroyMesh(GLMesh& mesh);
bool UCreateTexture(const char* filename, GLuint& textureId);                     // Create texture & destroy texture (below)
void UDestroyTexture(GLuint textureId);
void URender();                                                                   // Render graphics
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);  // Create shader & destroy shader (below)
void UDestroyShaderProgram(GLuint programId);

// Vertex Shader source code
const GLchar* vertexShaderSource = GLSL(330,  // Changed from 440 to 330
    layout(location = 0) in vec3 position;           // Position
    layout(location = 1) in vec4 color;              // Color
    layout(location = 2) in vec2 textureCoordinate;  // Texture
    layout(location = 3) in vec3 normal;             // Normal

    out vec2 vertexTextureCoordinate;                // Added for texture
    out vec4 vertexColor;                            // Vertex Color coords
    out vec3 oNormal;                                // normal
    out vec3 FragPos;                                // FragPos, passed to fragment shader

    // Global variables for the transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position.x, position.y, position.z, 1.0f);  // transforms vertices to clip coordinates
    vertexTextureCoordinate = textureCoordinate;                     // used for textures
    vertexColor = color;                                             // references incoming color data
    oNormal = mat3(transpose(inverse(model))) * normal;              // seting up normals
    FragPos = vec3(model * vec4(position, 1.0f));
}
);


// Fragment Shader source code
const GLchar* fragmentShaderSource = GLSL(330,  // Changed from 440 t0 330
    in vec4 vertexColor;                        // Variable to hold incoming color data from vertex shader
    in vec2 vertexTextureCoordinate;            // Texture coords
    in vec3 oNormal;                            // Passed in from vertex shader
    in vec3 FragPos;                            // Passed in from vertex shader

    out vec4 fragmentColor;

    uniform sampler2D uTexture;
    uniform vec3 objectColor;
    uniform vec3 lightColor;
    uniform vec3 lightPos;
    uniform vec3 viewPos;

void main()
{
    // Ambient
    float ambientStrength = 0.3f;
    vec3 ambient = ambientStrength * lightColor;
    // Diffuse
    vec3 norm = normalize(oNormal);
    vec3 lightDir = normalize(lightPos - FragPos);
    float diff = max(dot(norm, lightDir), 0.0);
    vec3 diffuse = diff * 2.5 * lightColor;
    // Specularity
    float specularStrength = 2.5f;
    vec3 viewDir = normalize(viewPos - FragPos);
    vec3 reflectDir = reflect(lightDir, norm);  // Changed this to not negative because it made the lighting weird. I dont think this is correct.
    float spec = pow(max(dot(viewDir, reflectDir), 0.0), 128);
    vec3 specular = specularStrength * spec * lightColor;
    // Result
    vec3 result = (ambient + diffuse + specular) * objectColor;
    fragmentColor = texture(uTexture, vertexTextureCoordinate) * vec4(result, 1.0f); // Sends texture to the GPU for rendering
}
);

// Light Vertex Shader source code
const GLchar* lightVertexShaderSource = GLSL(330,  // Changed from 440 to 330
    layout(location = 0) in vec3 position;         // Position

    // Global variables for the transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position.x, position.y, position.z, 1.0f);  // transforms vertices to clip coordinates
}
);

// Light Fragment Shader source code
const GLchar* lightFragmentShaderSource = GLSL(330,  // Changed from 440 t0 330
    out vec4 fragmentColor;

void main()
{
    fragmentColor = vec4(1.0f, 1.0f, 1.0f, 1.0f); // Sends texture to the GPU for rendering
}
);

// Images are loaded with Y axis going down, but OpenGL's Y axis goes up. We call this to flip the image
void flipImageVertically(unsigned char* image, int width, int height, int channels)  // Tells stb_image.g to flip the y-axis when loading images
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}

// Main function. Entry point to the OpenGL program
int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Create the mesh
    UCreateMesh(gMesh); // Calls the function to create the Vertex Buffer Object

    // Create the shader program
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(lightVertexShaderSource, lightFragmentShaderSource, gLightShaderId))
        return EXIT_FAILURE;

    // Loads a texture CYLINDER
    const char* texFilename = "ivory.jpg";  // Filename is specified here. Place image into the project's files for access
    if (!UCreateTexture(texFilename, gTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;  // Error if image cannot be accessed
        return EXIT_FAILURE;
    }
    glUseProgram(gProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 0);

    // Load texture PLANE
    const char* planeTexFilename = "Project Plane.jpg";
    if (!UCreateTexture(planeTexFilename, gPlaneTextureId))
    {
        cout << "Failed to load texture " << planeTexFilename << endl;
        return EXIT_FAILURE;
    }
    glUseProgram(gProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 0);

    // Load texture BOX 
    const char* BoxTexFilename = "cardboard.jpg";
    if (!UCreateTexture(BoxTexFilename, gBoxTextureId))
    {
        cout << "Failed to load texture " << BoxTexFilename << endl;
        return EXIT_FAILURE;
    }
    glUseProgram(gProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 0);

    // Load texture CAT
    const char* CatTexFilename = "ivory.jpg";
    if (!UCreateTexture(CatTexFilename, gCatTextureId))
    {
        cout << "Failed to load texture " << CatTexFilename << endl;
        return EXIT_FAILURE;
    }
    glUseProgram(gProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 0);

    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);    // Set the background color to black

    // Render loop
    while (!glfwWindowShouldClose(gWindow))  // Function that checks at the start of each loop if GLFW has been instructed to close
    {

        // The time elapsed is calculated inside the render loop
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        UProcessInput(gWindow);              // Determines wether relevant keys have been pressed and reacts accordingly
        URender();                           // Renders the frame
        glfwPollEvents();                    // Checks if any events are triggered such as keyboard input or mouse movements
    }

    // Clean up
    UDestroyMesh(gMesh);                     // Releases mesh data
    UDestroyTexture(gTextureId);             // Releases texture CYLINDER
    UDestroyTexture(gPlaneTextureId);        // Plane
    UDestroyTexture(gBoxTextureId);          // Cardboard Box
    UDestroyTexture(gCatTextureId);          // Cat desk light
    UDestroyShaderProgram(gProgramId);       // Releases shader program
    UDestroyShaderProgram(gLightShaderId);   // Releases light shader program
    glfwTerminate();                         // Cleans resources and exits the application
    return 0;                                // Exit code for successful program execution
}

// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    glfwInit();                                                     // Initialize GLFW
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);                  // Configure GLFW major version to 3
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);                  // Configure GLFW minor version to 3
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);  // Tell GLFW that we want to use the core profile
#ifdef __APPLE__                                                    // Additional code for Mac OS X users
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);  // Function that returns a window object: parameters are width, height, and window title
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);     // Called when framebuffer of window is resized
    glfwSetCursorPosCallback(*window, UMousePositionCallback);  // Called when mouse is moved
    glfwSetScrollCallback(*window, UMouseScrollCallback);       // Called when mouse wheel is scrolled
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);  // Called when mouse button is pressed or released

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);  // After this call, wherever we move the mouse it won't be visible and it should not leave the window

    // GLEW: initialize
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}

// Process Input
void UProcessInput(GLFWwindow* window)  // process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)  // If the escape key is pressed, the program will close
        glfwSetWindowShouldClose(window, true);
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)       // If the w key is pressed, the camera moves forward
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)       // If the s key is pressed, the camera moves backwards
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)       // If the a key is pressed, the camera moves left
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)       // If the d key is pressed, the camera moves right
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)       // If the q key is pressed, the camera moves up
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)       // If the e key is pressed, the camera moves down
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)       // If the p key is pressed, the projection switches to perspective
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS)       // If the o key is pressed, the projection switches to orthografic
        projection = glm::ortho(-5.0f, 5.0f, -5.0f, 5.0f, 0.1f, 100.0f);
}


// Resize window
void UResizeWindow(GLFWwindow* window, int width, int height)  // glfw: whenever the window size changed (by OS or user resize) this callback function executes
{
    glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)  // Checks if the last position is the same as the current position
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;  // Calculate the offset
    float yoffset = gLastY - ypos;  // Reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}


// glfw: whenever the mouse scroll wheel scrolls, this callback is called
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

// glfw: handle mouse button events
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:    // Left click
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:  // Middle click
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:  // Right click
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:                      // Other click
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}

// Render frame
void URender()
{
    // Enable z-depth
    glEnable(GL_DEPTH_TEST);

    // Clear the frame and z buffers
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // 1. Scales the object by 2
    glm::mat4 scale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));  // No change to the object
    // 3. Place object at the origin
    glm::mat4 translation = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model = translation * rotation * scale;

    // camera/view transformation
    glm::mat4 view = gCamera.GetViewMatrix();

    // Set the shader to be used
    glUseProgram(gProgramId);

    // Retrieves and passes transform matrices to the Shader program
    GLint modelLoc = glGetUniformLocation(gProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gProgramId, "view");
    GLint projLoc = glGetUniformLocation(gProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    //Get light and object color location
    GLint objectColorLoc = glGetUniformLocation(gProgramId, "objectColor");
    GLint lightColorLoc = glGetUniformLocation(gProgramId, "lightColor");
    GLint lightPosLoc = glGetUniformLocation(gProgramId, "lightPos");
    GLint viewPosLoc = glGetUniformLocation(gProgramId, "viewPos");

    // Assign Light and Object Colors
    //glUniform3f(objectColorLoc, 0.80f, 0.46f, 0.22f);  // Light brown color
    glUniform3f(lightColorLoc, 1.0f, 1.0f, 1.0f);      // White

    // Set light position
    glUniform3f(lightPosLoc, lightPosition.x, lightPosition.y, lightPosition.z);

    // Specify view position
    glUniform3f(viewPosLoc, gCamera.Position.x, gCamera.Position.y, gCamera.Position.z);

    // Activate the VBOs contained within the mesh's VAO CYLINDER ----------------------------------
    glBindVertexArray(gMesh.pyramidvao);

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId);

    glUniform3f(objectColorLoc, 0.933f, 0.878f, 0.588f);  // Ivory White

    glm::mat4 cylinderModel;
    glm::mat4 cylinderScale = glm::scale(glm::vec3(0.75f, 0.75f, 0.75f));
    glm::mat4 cylinderTranslation = glm::translate(glm::vec3(2.5f, 0.0f, -2.0f));
    cylinderModel = cylinderTranslation * rotation * cylinderScale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(cylinderModel));

    glDrawElements(GL_TRIANGLES, gMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    // Activate the VBOs contained within the mesh's VAO PLANE -------------------------------------
    glBindVertexArray(gMesh.planevao);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gPlaneTextureId);

    glUniform3f(objectColorLoc, 0.80f, 0.46f, 0.22f);  // Light brown color

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glDrawElements(GL_TRIANGLES, gMesh.nPlaneIndicies, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    glBindVertexArray(0);

    // Activate the VBOs contained within the mesh's VAO BOX --------------------------------------
    glBindVertexArray(gMesh.boxvao);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gBoxTextureId);

    glUniform3f(objectColorLoc, 0.690f, 0.552f, 0.431f);  // Cardboard Brown

    glm::mat4 boxModel;
    glm::mat4 boxScale = glm::scale(glm::vec3(1.25f,1.25f, 1.25f));
    glm::mat4 boxtRotation = glm::rotate(0.79f, glm::vec3(0.0, 1.0f, 0.0f));
    boxModel = translation * boxtRotation * boxScale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(boxModel));

    glDrawElements(GL_TRIANGLES, gMesh.nBoxIndicies, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    glBindVertexArray(0);

    // Activate the VBOs contained within the mesh's VAO CAT --------------------------------------
    glBindVertexArray(gMesh.catvao);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gCatTextureId);

    glUniform3f(objectColorLoc, 0.390f, 0.390f, 0.390f);  // Ivory White

    glm::mat4 catModel;
    glm::mat4 catScale = glm::scale(glm::vec3(1.0, 1.0f, 1.5f));
    glm::mat4 catRotation = glm::rotate(-1.57f, glm::vec3(1.0, 0.0f, 0.0f));
    glm::mat4 catTranslation = glm::translate(glm::vec3(-2.5f, 0.79f, -2.0f));
    catModel = catTranslation * catRotation * catScale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(catModel));

    glDrawElements(GL_TRIANGLES, gMesh.nCatIndicies, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    glBindVertexArray(0);

    // Activate the VBOs contained within the mesh's VAO EGG --------------------------------------
    glBindVertexArray(gMesh.eggvao);

    glUniform3f(objectColorLoc, 0.721f, 0.937f, 0.105f);  // Lime Green

    glm::mat4 eggModel;
    glm::mat4 eggScale = glm::scale(glm::vec3(0.5, 0.5f, 0.75f));
    glm::mat4 eggRotation = glm::rotate(2.0f, glm::vec3(0.0, 1.0f, 0.0f));
    glm::mat4 eggTranslation = glm::translate(glm::vec3(0.0f, 0.55f, -3.5f));
    eggModel = eggTranslation * eggRotation * eggScale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(eggModel));

    glDrawElements(GL_TRIANGLES, gMesh.nEggIndicies, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    glBindVertexArray(0);

    // RENDERING LIGHT SOURCE ---------------------------------------------------------------------

    glUseProgram(gLightShaderId);

    // Retrieves and passes transform matrices to the Light Shader program
    GLint lightModelLoc = glGetUniformLocation(gLightShaderId, "model");
    GLint lightViewLoc = glGetUniformLocation(gLightShaderId, "view");
    GLint lightProjLoc = glGetUniformLocation(gLightShaderId, "projection");

    glUniformMatrix4fv(lightViewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(lightProjLoc, 1, GL_FALSE, glm::value_ptr(projection));

    glBindVertexArray(gMesh.lampvao);

    translation = glm::translate(lightPosition);
    //rotation = glm::rotate(180.0f, glm::vec3(1.0, 0.0f, 0.0f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(lightModelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gMesh.nLampIndicies, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);
    // Deactivate the shader program
    glUseProgram(0);

    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}

const int numCircles = 2;     // Parameter for how many circles are being drawn, a cylinder will have 2
const int radius = 1;         // Parameter for the radius of the cylinder [UPDATABLE]
const float height = 2.0;     // Parameter for the height of the cylinder (the z- coordinate) [UPDATABLE]
const int numTriangles = 16;  // Parameter for the number of triangles (slices) per circle- more will make a better circle, less will result in more straight lines [UPDATABLE]
const int numIndicies = 6 * numTriangles * numCircles;          // CHANGED 3 TO 6 (needs to be more, since we are connecting triangles now, theres 6 more indicies per 2 triangles)
const int vertArraySize = 10 * (numTriangles + 1) * numCircles;  // 10 enteries per line * number of points per circle (+1 for center point) * number of circles
const int halfwaySize = vertArraySize / 2;                      // Straightforward, used in calculations below

// Implements the UCreateMesh function
void UCreateMesh(GLMesh& mesh)
{
    GLfloat verts[vertArraySize];         // Create both arrays here, and the size is dependant on variables above
    GLushort indices[numIndicies];
    double angle = 360.0 / numTriangles;  // Calculate the internal angle of each triangle

    // Create the first circle ----------------------------------------------------------------------------------
    // Add the center point for first circle, color: white
    verts[0] = 0.0;  // CHANGE TO xCoord
    verts[1] = 0.0;
    verts[2] = 0.0;
    // COLOR
    verts[3] = 1.0;
    verts[4] = 1.0;
    verts[5] = 1.0;
    verts[6] = 1.0;
    // Normal
    verts[7] = 0.0;
    verts[8] = 0.0;
    verts[9] = 1.0;

    //  Add the verticies of all points on the first circle using math, color: white
    for (int i = 0; i < numTriangles; ++i) {
        int j = (i + 1) * 10;
        double theta = ((i * angle) * PI) / 180.0;

        float x = (radius * cos(theta));
        float y = 0;  // no height, so we keep this as 0 always for the first circle
        float z = (radius * sin(theta));

        verts[j + 0] = x;
        verts[j + 1] = y;
        verts[j + 2] = z;
        // COLOR
        verts[j + 3] = 1.0;
        verts[j + 4] = 1.0;
        verts[j + 5] = 1.0;
        verts[j + 6] = 1.0;
        // Normal
        verts[j + 7] = 0.0;
        verts[j + 8] = 0.0;
        verts[j + 9] = 1.0;
    };

    // Creates the indicies for the first circle, first is always 0 because the midpoint connects all triangles
    for (GLushort i = 0; i < numTriangles; ++i) {
        int j = i * 3;

        indices[j + 0] = 0;
        indices[j + 1] = i + 1;
        indices[j + 2] = i + 2;

    };

    indices[numIndicies / 4 - 1] = 1;  // The last indicie for the first circle should be 1, determined this by looking at the pattern

    // Create the second circle --------------------------------------------------------------------------------
    // Add the mid point for the second circle, color: magenta
    verts[halfwaySize] = 0.0;
    verts[halfwaySize + 1] = height;  // set to the height variable
    verts[halfwaySize + 2] = 0.0;
    // COLOR
    verts[halfwaySize + 3] = 1.0;
    verts[halfwaySize + 4] = 0.0;
    verts[halfwaySize + 5] = 1.0;
    verts[halfwaySize + 6] = 1.0;
    // normal
    verts[halfwaySize + 7] = 0.0;
    verts[halfwaySize + 8] = 0.0;
    verts[halfwaySize + 9] = 1.0;

    //  Add the verticies of all points on the second circle using math, color: magenta
    for (int i = 0; i < numTriangles; ++i) {
        int j = (halfwaySize + ((i + 1) * 10));
        double theta = ((i * angle) * PI) / 180.0;

        float x = (radius * cos(theta));
        float y = height;  // y is the height variable
        float z = (radius * sin(theta));

        verts[j + 0] = x;
        verts[j + 1] = y;  // Height, y
        verts[j + 2] = z;
        // COLOR
        verts[j + 3] = 1.0;
        verts[j + 4] = 0.0;
        verts[j + 5] = 1.0;
        verts[j + 6] = 1.0;
        // normal
        verts[j + 7] = 0.0;
        verts[j + 8] = 0.0;
        verts[j + 9] = 1.0;
    };

    // Creates the indicies for the second circle, first is always numTriangles + 1 because that is the midpoint of the second circle that connects all triangles
    for (GLushort i = numTriangles; i < numTriangles * numCircles; ++i) {
        int j = i * 3;

        indices[j + 0] = numTriangles + 1;
        indices[j + 1] = i + 2;
        indices[j + 2] = i + 3;

    };

    indices[numIndicies / 2 - 1] = numTriangles + 2; // The last indicie for the second circle should be numTriangles + 2

    // Connecting the two circles -------------------------------------------------------------------------------
    // Circle 1 (point 1 and point 2)
    int p1 = 1;
    int p2 = 2;

    // Circle 2 (point 3 and point 4)
    int p3 = numTriangles + 2;
    int p4 = p3 + 1;

    // Connects the circles
    for (GLushort i = numTriangles; i < numTriangles * numCircles; ++i, ++p1, ++p2, ++p3, ++p4) {
        int j = i * 6;

        if (p1 == numTriangles + 1) {
            p1 = 1;
        }

        if (p2 == numTriangles + 1) {
            p2 = 1;
        }

        if (p3 == ((numTriangles * 2) + 2)) {
            p3 = (numTriangles + 2);
        }

        if (p4 == ((numTriangles * 2) + 2)) {
            p4 = (numTriangles + 2);
        }

        // creates the indicies to connect the two circles
        if (p1 > p2) {
            GLushort a = p1;
            p1 = p2;
            p2 = a;
            indices[j + 0] = p1;
            indices[j + 1] = p2;
            indices[j + 2] = p3;
        }

        if (p3 > p4) {
            GLushort b = p3;
            p3 = p4;
            p4 = b;
            indices[j + 3] = p1;
            indices[j + 4] = p3;
            indices[j + 5] = p4;
        }

        else {
            indices[j + 0] = p1;
            indices[j + 1] = p2;
            indices[j + 2] = p3;
            indices[j + 3] = p2;
            indices[j + 4] = p3;
            indices[j + 5] = p4;
        };

    };

    // CARDBOARD BOX --------------------------------------------------------------------------------
    float boxHeight = 2.0;

    GLfloat boxVerts[] = {
        // x, y, z coords        // Texture   // Normals
        // TOP FACE
         1.0f, boxHeight,-1.0f,  1.0f, 0.0f,  0.0f, 0.0f, 0.1f, // Point E top, bottom right 0
         1.0f, boxHeight, 1.0f,  1.0f, 1.0f,  0.0f, 0.0f, 0.1f, // Point F top, top right 1
        -1.0f, boxHeight, 1.0f,  0.0f, 1.0f,  0.0f, 0.0f, 0.1f, // Point G top, top left 2
        -1.0f, boxHeight,-1.0f,  0.0f, 0.0f,  0.0f, 0.0f, 0.1f, // Point H top, bottom left 3

        // FRONT SIDE
         1.0f, 0.0f,-1.0f,       1.0f, 0.0f,  0.0f, 0.0f, 0.1f, // Point A bottom, bottom right 8
         1.0f, boxHeight,-1.0f,  1.0f, 1.0f,  0.0f, 0.0f, 0.1f, // Point E top, bottom right 9
        -1.0f, boxHeight,-1.0f,  0.0f, 1.0f,  0.0f, 0.0f, 0.1f, // Point H top, bottom left 10
        -1.0f, 0.0f,-1.0f,       0.0f, 0.0f,  0.0f, 0.0f, 0.1f, // Point D bottom, bottom left 11

        // RIGHT SIDE
         1.0f, 0.0f,-1.0f,       0.0f, 0.0f,  0.0f, 0.0f, 0.1f, // Point A bottom, bottom right 12
         1.0f, boxHeight,-1.0f,  0.0f, 1.0f,  0.0f, 0.0f, 0.1f,// Point E top, bottom right 13
         1.0f, boxHeight, 1.0f,  1.0f, 1.0f,  0.0f, 0.0f, 0.1f, // Point F top, top right 14
         1.0f, 0.0f, 1.0f,       1.0f, 0.0f,  0.0f, 0.0f, 0.1f, // Point B bottom, top right 15

         // BACK SIDE
         1.0f, 0.0f, 1.0f,       0.0f, 0.0f,  0.0f, 0.0f, 0.1f, // Point B bottom, top right 16
         1.0f, boxHeight, 1.0f,  0.0f, 1.0f,  0.0f, 0.0f, 0.1f, // Point F top, top right 17
        -1.0f, boxHeight, 1.0f,  1.0f, 1.0f,  0.0f, 0.0f, 0.1f, // Point G top, top left 18
        -1.0f, 0.0f, 1.0f,       1.0f, 0.0f,  0.0f, 0.0f, 0.1f, // Point C bottom, top left 19

        // LEFT SIDE
        -1.0f, 0.0f, 1.0f,       0.0f, 0.0f,  0.0f, 0.0f, 0.1f, // Point C bottom, top left 20
        -1.0f, boxHeight, 1.0f,  0.0f, 1.0f,  0.0f, 0.0f, 0.1f, // Point G top, top left 21
        -1.0f, boxHeight,-1.0f,  1.0f, 1.0f,  0.0f, 0.0f, 0.1f, // Point H top, bottom left 22
        -1.0f, 0.0f,-1.0f,       1.0f, 0.0f,  0.0f, 0.0f, 0.1f // Point D bottom, bottom left 23
    };

    GLushort boxIndicies[] = {
        // TOP FACE
        0, 1, 2,
        0, 2, 3,
        // FRONT SIDE
        4, 5, 6,
        4, 6, 7,
        // RIGHT SIDE
        8, 9, 10,
        8, 10, 11,
        // BACK SIDE
        12, 13, 14,
        12, 14, 15,
        // LEFT SIDE
        16, 17, 18,
        16, 18, 19
    };

    // LAMP SOURCE --------------------------------------------------------------------------------
    GLfloat lampVerts[] = {
        // x, y, z coords     // Texture
        // TOP FACE
         1.0f, 0.0f,-1.0f,  // Point E top, bottom right 0
         1.0f, 0.0f, 1.0f,  // Point F top, top right 1
        -1.0f, 0.0f, 1.0f,  // Point G top, top left 2
        -1.0f, 0.0f,-1.0f   // Point H top, bottom left 3
    };

    GLushort lampIndicies[] = {
        // TOP FACE
        0, 1, 2,
        0, 2, 3
    };

    // PLANE ----------------------------------------------------------------------------------------
    GLfloat planeVerts[] = {
      -7.0f,  0.0f, -5.0f,  0.0f, 0.0f,  0.0f, 0.0f, 0.1f, // Bottom left corner 0
      -7.0f,  0.0f,  5.0f,  0.0f, 1.0f,  0.0f, 0.0f, 0.1f, // Top left corner 1
       7.0f,  0.0f,  5.0f,  1.0f, 1.0f,  0.0f, 0.0f, 0.1f, // Top right corner 2
       7.0f,  0.0f, -5.0f,  1.0f, 0.0f,  0.0f, 0.0f, 0.1f  // Bottom right corner 3

    };

    GLushort planeIndicies[] = {
        0,1,2,
        0,2,3
    };

    // CAT OBJECT ----------------------------------------------------------------------------------
    GLfloat catVerts[] = {
        // x,y,z coords
        0.00f, 0.55f, 0.94f,  0.0f, 0.0f, 0.1f,  // A (top ring) 0
        0.00f, 0.95f, 0.54f,  0.0f, 0.0f, 0.1f,  // B (second ring) 1
        0.00f, 1.09f, 0.0f,   0.0f, 0.0f, 0.1f,  // C (third ring) 2
        0.00f, 0.96f,-0.52f,  0.0f, 0.0f, 0.1f,  // D (bottom ring) 3

        0.48f, 0.28f, 0.94f,  0.0f, 0.0f, 0.1f,  // E (top ring) 4
        0.82f, 0.48f, 0.54f,  0.0f, 0.0f, 0.1f,  // F (second ring) 5
        0.95f, 0.55f, 0.00f,  0.0f, 0.0f, 0.1f,  // G (third ring) 6
        0.83f, 0.48f,-0.52f,  0.0f, 0.0f, 0.1f,  // H (bottom ring) 7

        0.48f,-0.28f, 0.94f,  0.0f, 0.0f, 0.1f,  // I (top ring) 8
        0.82f,-0.48f, 0.54f,  0.0f, 0.0f, 0.1f,  // J (second ring) 9
        0.95f,-0.55f, 0.00f,  0.0f, 0.0f, 0.1f,  // K (third ring) 10
        0.83f,-0.48f,-0.52f,  0.0f, 0.0f, 0.1f,  // L (bottom ring) 11

        0.00f,-0.53f, 0.94f,  0.0f, 0.0f, 0.1f,  // M (top ring) 12
        0.00f,-0.95f, 0.54f,  0.0f, 0.0f, 0.1f,  // N (second ring) 13
        0.00f,-1.09f, 0.00f,  0.0f, 0.0f, 0.1f,  // O (third ring) 14
        0.00f,-0.96f,-0.52f,  0.0f, 0.0f, 0.1f,  // P (bottom ring) 15

        0.00f, 0.00f, 1.09f,  0.0f, 0.0f, 0.1f,  // Q TOP POINT 16

        -0.48f,-0.28f, 0.94f,  0.0f, 0.0f, 0.1f,  // R (top ring) 17
        -0.82f,-0.48f, 0.54f,  0.0f, 0.0f, 0.1f,  // S (second ring) 18
        -0.95f,-0.55f, 0.00f,  0.0f, 0.0f, 0.1f,  // T (third ring) 19
        -0.83f,-0.48f,-0.52f,  0.0f, 0.0f, 0.1f,  // U (bottom ring) 20

        -0.48f, 0.28f, 0.94f,  0.0f, 0.0f, 0.1f,  // V (top ring) 21
        -0.82f, 0.48f, 0.54f,  0.0f, 0.0f, 0.1f,  // W (second ring) 22
        -0.95f, 0.55f, 0.00f,  0.0f, 0.0f, 0.1f,  // Z (third ring) 23
        -0.83f, 0.48f,-0.52f,  0.0f, 0.0f, 0.1f,  // A1 (bottom ring) 24

        0.14f,-0.26f, 1.33f,  0.0f, 0.0f, 0.1f,  // B1 (ear point) 25
        -0.14, 0.26f, 1.33f,  0.0f, 0.0f, 0.1f   // C1 (ear point) 26

    };

    GLushort catIndicies[] = {
        // Top ring
        0, 1, 22,
        0, 21, 22,
        18, 21, 22,
        17, 18, 21,
        13, 17, 18,
        12, 13, 17,
        9, 12, 13,
        8, 9, 12,
        5, 8, 9,
        4, 5, 8,
        1, 4, 5,
        0, 1, 4,
        // Second ring
        1, 2, 23,
        1, 22, 23,
        18, 19, 22,
        19, 22, 23,
        13, 14, 18,
        14, 18, 19,
        9, 10, 13,
        10, 13, 14,
        5, 6, 9,
        6, 9, 10,
        1, 2, 5,
        2, 5, 6,
        // Third ring
        2, 3, 23,
        3, 23, 24,
        19, 20, 23,
        20, 23, 24,
        14, 15, 19,
        15, 19, 20,
        10, 11, 14,
        11, 14, 15,
        6, 7, 10,
        7, 10, 11,
        2, 3, 6,
        3, 6, 7,
        // Top of Cat
        0, 4, 16,
        4, 8, 16,
        12, 16, 17,
        16, 17, 21,
        // EAR ONE
        0, 21, 26,
        0, 16, 26,
        16, 21, 26,
        // EAR TWO
        8, 12, 25,
        8, 16, 25,
        12, 16, 25
    };

    // Easter Egg Object ------------------------------------------------------------------------------------------------------------------------------------
    GLfloat eggVerts[] = {
        0.00f, 0.50f, 0.87f,  0.0f, 0.0f, 0.1f,  // A (top row) 0
        0.00f, 0.87f, 0.50f,  0.0f, 0.0f, 0.1f,  // B (second row) 1
        0.00f, 1.00f, 0.00f,  0.0f, 0.0f, 0.1f,  // C (third row) 2
        0.00f, 0.87f,-0.50f,  0.0f, 0.0f, 0.1f,  // D (fourth row) 3
        0.00f, 0.50f,-0.87f,  0.0f, 0.0f, 0.1f,  // E (bottom row) 4

        0.43f, 0.25f, 0.87f,  0.0f, 0.0f, 0.1f,  // F (top row) 5
        0.75f, 0.43f, 0.50f,  0.0f, 0.0f, 0.1f,  // G (second row) 6 
        0.87f, 0.50f, 0.00f,  0.0f, 0.0f, 0.1f,  // H (third row) 7
        0.75f, 0.43f,-0.50f,  0.0f, 0.0f, 0.1f,  // I (fourth row) 8
        0.43f, 0.25f,-0.87f,  0.0f, 0.0f, 0.1f,  // J (bottom row) 9

        0.43f,-0.25f, 0.87f,  0.0f, 0.0f, 0.1f,  // K (top row) 10
        0.75f,-0.43f, 0.50f,  0.0f, 0.0f, 0.1f,  // L (second row) 11
        0.87f,-0.50f, 0.00f,  0.0f, 0.0f, 0.1f,  // M (third row) 12
        0.75f,-0.43f,-0.50f,  0.0f, 0.0f, 0.1f,  // N (fourth row) 13
        0.43f,-0.25f,-0.87f,  0.0f, 0.0f, 0.1f,  // O (bottom row) 14

        0.00f,-0.50f, 0.87f,  0.0f, 0.0f, 0.1f,  // P (top row) 15
        0.00f,-0.87f, 0.50f,  0.0f, 0.0f, 0.1f,  // Q (second row) 16
        0.00f,-1.00f, 0.00f,  0.0f, 0.0f, 0.1f,  // R (third row) 17
        0.00f,-0.87f,-0.50f,  0.0f, 0.0f, 0.1f,  // S (fourth row) 18
        0.00f,-0.50f,-0.87f,  0.0f, 0.0f, 0.1f,  // T (bottom row) 19

        0.00f, 0.00f,-1.00f,  0.0f, 0.0f, 0.1f,  // U BOTTOM POINT 20
        0.00f, 0.00f, 1.00f,  0.0f, 0.0f, 0.1f,  // V TOP POINT 21

        -0.43f,-0.25f, 0.87f,  0.0f, 0.0f, 0.1f,  // W (top row) 22
        -0.75f,-0.43f, 0.50f,  0.0f, 0.0f, 0.1f,  // Z (second row) 23
        -0.87f,-0.50f, 0.00f,  0.0f, 0.0f, 0.1f,  // A1 (third row) 24
        -0.75f,-0.43f,-0.50f,  0.0f, 0.0f, 0.1f,  // B1 (fourth row) 25
        -0.43f,-0.25f,-0.87f,  0.0f, 0.0f, 0.1f,  // C1 (bottom row) 26

        -0.43f, 0.25f, 0.87f,  0.0f, 0.0f, 0.1f,  // D1 (top row) 27
        -0.75f, 0.43f, 0.50f,  0.0f, 0.0f, 0.1f,  // E1 (second row) 28
        -0.87f, 0.50f, 0.00f,  0.0f, 0.0f, 0.1f,  // F1 (third row) 29
        -0.75f, 0.43f,-0.50f,  0.0f, 0.0f, 0.1f,  // G1 (fourth row) 30
        -0.43f, 0.25f,-0.87f,  0.0f, 0.0f, 0.1f   // H1 (bottom row) 31
    };

    GLushort eggIndicies[] = {
        // TOP
        0, 21, 27,
        21, 22, 27,
        15, 21, 22,
        10, 15, 21,
        5, 10, 21,
        0, 5, 21,
        // First Strip
        0, 1, 27,
        1, 27, 28,
        22, 27, 28,
        22, 23, 28,
        15, 16, 22,
        16, 22, 23,
        10, 11, 15,
        11, 15, 16,
        5, 6, 10,
        6, 10, 11,
        0, 1, 5,
        1, 5, 6,
        // Second Strip
        1, 2, 28,
        2, 28, 29,
        23, 24, 28,
        24, 28, 29,
        16, 17, 23,
        17, 23, 24,
        11, 12, 16,
        12, 16, 17,
        6, 7, 11,
        7, 11, 12,
        1, 2, 6,
        2, 6, 7,
        //Third Strip
        2, 3, 29,
        3, 29, 30,
        24, 25, 29,
        25, 29, 30,
        17, 18, 24,
        18, 24, 25,
        12, 13, 17,
        13, 17, 18,
        7, 8, 12,
        8, 12, 13,
        2, 3, 7,
        3, 7, 8,
        // Fourth Strip
        3, 4, 30,
        4, 30, 31,
        25, 26, 30,
        26, 30, 31,
        18, 19, 25,
        19, 25, 26,
        13, 14, 18,
        14, 18, 19,
        8, 9, 13,
        9, 13, 14,
        3, 4, 8,
        4, 8, 9,
        // BOTTOM
        4, 20, 31,
        4, 9, 20,
        9, 14, 20,
        14, 19, 20,
        19, 20, 26,
        20, 26, 31
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerColor = 4;
    const GLuint floatsPerTexture = 2;

    // CYLINDER OBJECT --------------------------------------------------------------------------------------------------------------------------------------
    glGenVertexArrays(1, &mesh.pyramidvao);  // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.pyramidvao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);                          // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);  // Sends vertex or coordinate data to the GPU

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    //GLint stride = sizeof(float) * (floatsPerVertex + floatsPerColor + floatsPerTexture);   // COMMENTED OUT because it wasnt being used. Not sure why.

    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 10 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    // color attribute
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 10 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    // normal
    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 10 * sizeof(float), (void*)(7 * sizeof(float)));
    glEnableVertexAttribArray(3);

    glBindVertexArray(0);  // Unbind VOA or close off

    // BOX OBJECT ------------------------------------------------------------------------------------------------------------------------------------------
    glGenVertexArrays(1, &mesh.boxvao);  // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.boxvao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.boxvbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.boxvbos[0]);                               // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(boxVerts), boxVerts, GL_STATIC_DRAW);   // Sends vertex or coordinate data to the GPU

    mesh.nBoxIndicies = sizeof(boxIndicies) / sizeof(boxIndicies[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.boxvbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(boxIndicies), boxIndicies, GL_STATIC_DRAW);

    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    // Texture attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(2);
    // Normals
    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(5 * sizeof(float)));
    glEnableVertexAttribArray(3);

    glBindVertexArray(0);

    // LAMP SOURCE ----------------------------------------------------------------------------------------------------------------------------------------
    glGenVertexArrays(1, &mesh.lampvao);  // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.lampvao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.lampvbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.lampvbos[0]);                               // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(lampVerts), lampVerts, GL_STATIC_DRAW);  // Sends vertex or coordinate data to the GPU

    mesh.nLampIndicies = sizeof(lampIndicies) / sizeof(lampIndicies[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.lampvbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(lampIndicies), lampIndicies, GL_STATIC_DRAW);

    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glBindVertexArray(0);  // Unbind VOA or close off

    // CAT Object ----------------------------------------------------------------------------------------------------------------------------------------
    glGenVertexArrays(1, &mesh.catvao);  // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.catvao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.catvbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.catvbos[0]);                               // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(catVerts), catVerts, GL_STATIC_DRAW);  // Sends vertex or coordinate data to the GPU

    mesh.nCatIndicies = sizeof(catIndicies) / sizeof(catIndicies[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.catvbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(catIndicies), catIndicies, GL_STATIC_DRAW);

    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    // Normals
    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(3);

    glBindVertexArray(0);  // Unbind VOA or close off

    // EGG Object ----------------------------------------------------------------------------------------------------------------------------------------
    glGenVertexArrays(1, &mesh.eggvao);  // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.eggvao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.eggvbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.eggvbos[0]);                               // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(eggVerts), eggVerts, GL_STATIC_DRAW);  // Sends vertex or coordinate data to the GPU

    mesh.nEggIndicies = sizeof(eggIndicies) / sizeof(eggIndicies[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.eggvbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(eggIndicies), eggIndicies, GL_STATIC_DRAW);

    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    // Normals
    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(3);

    glBindVertexArray(0);  // Unbind VOA or close off

    // PLANE OBJECT ---------------------------------------------------------------------------------------------------------------------------------------
    glGenVertexArrays(1, &mesh.planevao);  // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.planevao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.planevbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.planevbos[0]);                               // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(planeVerts), planeVerts, GL_STATIC_DRAW);  // Sends vertex or coordinate data to the GPU

    mesh.nPlaneIndicies = sizeof(planeIndicies) / sizeof(planeIndicies[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.planevbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(planeIndicies), planeIndicies, GL_STATIC_DRAW);

    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    // Texture attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(2);
    // Normals
    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(5 * sizeof(float)));
    glEnableVertexAttribArray(3);

    glBindVertexArray(0);

}

// Destroy Mesh: Clean up
void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.pyramidvao);
    glDeleteBuffers(2, mesh.vbos);
    glDeleteVertexArrays(1, &mesh.planevao);
    glDeleteBuffers(2, mesh.planevbos);
    glDeleteVertexArrays(1, &mesh.boxvao);
    glDeleteBuffers(2, mesh.boxvbos);
    glDeleteVertexArrays(1, &mesh.lampvao);
    glDeleteBuffers(2, mesh.lampvbos);
    glDeleteVertexArrays(1, &mesh.catvao);
    glDeleteBuffers(2, mesh.catvbos);
    glDeleteVertexArrays(1, &mesh.eggvao);
    glDeleteBuffers(2, mesh.eggvbos);
}

// Generate and load the texture
bool UCreateTexture(const char* filename, GLuint& textureId)  // Uses the filename specified above
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);  // Flips the image

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}

// Destroy Texture: Clean up
void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}

// Create fragment and vertex shaders
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    int success = 0;    // Integer to indicate success
    char infoLog[512];  // Storage container for error messages (if any)

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Vertex shader -------------------------------------------
    glCompileShader(vertexShaderId);                             // Compile the vertex shader

    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);  // check for shader compile errors
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;  // Print error message

        return false;
    }
    // Fragment shader ------------------------------------------
    glCompileShader(fragmentShaderId);                             // Compile the fragment shader

    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);  // Check for shader compile errors
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;  // Print error message

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program

    glGetProgramiv(programId, GL_LINK_STATUS, &success);  // check for linking errors
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;  // Print error message

        return false;
    }

    glUseProgram(programId);  // Uses the shader program

    return true;
}

// Destroy Shader: Clean up
void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}